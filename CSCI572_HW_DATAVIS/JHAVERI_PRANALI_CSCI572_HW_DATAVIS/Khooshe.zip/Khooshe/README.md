<p align="center">
  <img src="https://github.com/MBoustani/Khooshe/blob/master/logo.png"  width="300"/>
</p>
Khooshe
======

Big GeoSptial Data Points Visualization Tool

[Khooshe's Document](https://github.com/MBoustani/Khooshe/wiki)

[Demo](http://mboustani.github.io/khooshe.html)
