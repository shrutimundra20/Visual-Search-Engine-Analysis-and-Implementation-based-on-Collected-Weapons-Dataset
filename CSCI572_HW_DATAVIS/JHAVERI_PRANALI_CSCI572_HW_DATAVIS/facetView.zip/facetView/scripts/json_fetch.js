jQuery(document).ready(function($) {
    $('.facet-view-simple').facetview({
        search_url: 'http://localhost:8983/solr/memex/select?',
        search_index: 'solr',
        datatype: 'json',
        paging: {
            from: 0,
            size: 10
        },
        facets: [
            {'field' : 'tika_location.geo_name'}
            
        ]
        
    });
});